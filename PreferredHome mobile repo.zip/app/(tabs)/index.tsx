// app/(tabs)/index.tsx — Build 3.2.20 Closeout Hotfix
// Fixed: TOP 3 label now uses textStyles.sectionTitle (headingLabel removed at Closeout).
// Import updated: headingLabel removed, textStyles already present.
// No other changes.

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { View, Text, ActivityIndicator, RefreshControl, ScrollView } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { colors } from "../../styles/colors";
import { textStyles } from "../../styles/typography";
import { TopBar } from "../../components/TopBar";
import { ListingCard } from "../../components/ListingCard";
import { MenuPanel, type SubPanelKey } from "../../components/MenuPanel";
import { ProfilePanel } from "../../components/ProfilePanel";
import { CriteriaPanel } from "../../components/CriteriaPanel";
import { SettingsPanel } from "../../components/SettingsPanel";
import { useListings } from "../../lib/useListings";
import { applyOrder } from "../../lib/orderApply";
import { loadOrder } from "../../lib/orderStorage";
import type { ListingUI } from "../../lib/types";

function StatPill({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 12 }}>
      <Text style={{ color: colors.textSecondary, fontSize: textStyles.micro.fontSize, letterSpacing: 0.7 }}>
        {label.toUpperCase()}
      </Text>
      <Text style={{ color: colors.textPrimary, marginTop: 6, fontSize: textStyles.cardTitle.fontSize, fontWeight: textStyles.cardTitle.fontWeight }}>
        {value}
      </Text>
    </View>
  );
}

function fmtMoney(n: number) {
  if (!Number.isFinite(n)) return "—";
  return `$${Math.round(n).toLocaleString()}`;
}

export default function HomeScreen() {
  const { listings, loading, refreshing, error, refresh } = useListings();
  const insets = useSafeAreaInsets();
  const topBarHeight = insets.top + 53;

  const [preferredTop, setPreferredTop] = useState<ListingUI[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSubPanel, setActiveSubPanel] = useState<SubPanelKey | null>(null);

  useFocusEffect(
    useCallback(() => {
      refresh();
    }, [])
  );

  useEffect(() => {
    (async () => {
      const saved = await loadOrder();
      const ordered = applyOrder(listings, saved);
      setPreferredTop(ordered.preferred.slice(0, 3));
    })();
  }, [listings]);

  const stats = useMemo(() => {
    const rents = listings.map((l) => l.baseRent ?? 0).filter((n) => n > 0);
    const count = listings.length;
    if (!rents.length) return { count, min: null, max: null, avg: null, median: null };
    const sorted = [...rents].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    const median = sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
    const min = sorted[0];
    const max = sorted[sorted.length - 1];
    const avg = rents.reduce((a, b) => a + b, 0) / rents.length;
    return { count, min, max, avg, median };
  }, [listings]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <TopBar title="PreferredHome" onPressMenu={() => setMenuOpen(true)} />

      {loading ? (
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <ActivityIndicator />
          <Text style={{ color: colors.textSecondary, marginTop: 10 }}>Loading...</Text>
        </View>
      ) : (
        <ScrollView
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
          contentContainerStyle={{ padding: 16, gap: 14 }}
        >
          {/* Stats section */}
          <View style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 18, padding: 14 }}>
            <Text style={{ color: colors.textPrimary, fontSize: textStyles.subHeader.fontSize, fontWeight: textStyles.subHeader.fontWeight }}>
              Base Rent Snapshot
            </Text>
            {!stats.min ? (
              <Text style={{ color: colors.textSecondary, marginTop: 8 }}>No rent data yet.</Text>
            ) : (
              <>
                <Text style={{ color: colors.textSecondary, marginTop: 6, fontSize: textStyles.bodySmall.fontSize }}>
                  {stats.count} listings with base rent
                </Text>
                <View style={{ flexDirection: "row", gap: 10, marginTop: 12 }}>
                  <StatPill label="Lowest" value={fmtMoney(stats.min)} />
                  <StatPill label="Baseline" value={fmtMoney(stats.median!)} />
                </View>
                <View style={{ flexDirection: "row", gap: 10, marginTop: 10 }}>
                  <StatPill label="Average" value={fmtMoney(stats.avg!)} />
                  <StatPill label="Highest" value={fmtMoney(stats.max!)} />
                </View>
              </>
            )}
          </View>

          {/* Top 3 preferred */}
          {preferredTop.length > 0 && (
            <View style={{ gap: 10 }}>
              <Text style={textStyles.sectionTitle}>Top 3</Text>
              {preferredTop.map((item) => (
                <ListingCard
                  key={item.id}
                  listing={item}
                  hideActions
                  compareSelected={false}
                  onTogglePreferred={() => {}}
                  onToggleCompare={() => {}}
                  onView={() => {}}
                  onEdit={() => router.push({ pathname: "/edit", params: { id: item.id } })}
                  onDelete={() => {}}
                />
              ))}
            </View>
          )}
        </ScrollView>
      )}

      {/* Menu dropdown */}
      {menuOpen && (
        <MenuPanel
          topOffset={topBarHeight}
          onSelectPanel={(p) => { setMenuOpen(false); setActiveSubPanel(p); }}
          onClose={() => setMenuOpen(false)}
        />
      )}

      {activeSubPanel === "profile" && (
        <ProfilePanel topOffset={topBarHeight} onClose={() => setActiveSubPanel(null)} />
      )}
      {activeSubPanel === "criteria" && (
        <CriteriaPanel topOffset={topBarHeight} onClose={() => setActiveSubPanel(null)} />
      )}
      {activeSubPanel === "settings" && (
        <SettingsPanel topOffset={topBarHeight} onClose={() => setActiveSubPanel(null)} />
      )}
    </View>
  );
}
